# Drawing Studio V0.6.7 복원 검증

검증일: 2026-09-20. 상태: V0.6.7 복원 완료. 최종 코드 재검토 및 전달 ZIP의 새 폴더 재검증 모두 통과. V0.6.8은 시작하지 않았다.

## 기준과 범위

유일한 원본은 `/코딩/recovery-work/drawing-webapp-v0.6.9-base.zip`이다. 기존 프로젝트를 교체한 새 구현이 아니라, 해당 원본에 V0.6.7 Text/Manga/Materials만 복원했다. V0.6.8 이상은 진행하지 않았다.

- 원본 SHA-256: `be7afc35e91d2014a5c218db72e678c7af5633a2bfc8627fb67d38eac7f5d52d`
- 원본 ZIP: 229,368바이트, 154항목, CRC 정상.
- 원본 검증: 184개 테스트와 production build 통과. TypeScript 5.6.3을 고정했다.
- 전달 소스 커밋: `6752279bedd49eaa586e28da020567910a247648` (실제 최종 기능 수정 `fceb38f`).
- 프로젝트 파일은 기존 `formatVersion: 1`, persistence foundation `appVersion: 0.6.9` 유지. 패키지 버전 `0.6.7-restored`는 복원 범위를 표시한다.

## 실제 구현

Text, Balloon, Panel, Screen Tone, Manga Effect, Material을 편집 가능한 레이어로 구현했다. 생성 후 속성 변경, 레이어 복제·삭제·순서·표시·불투명도·블렌드, Undo/Redo, Navigator, Flatten, PNG 내보내기와 프로젝트 저장에 연결했다.

텍스트는 여러 줄·정렬·간격·외곽선·위치를 지원한다. 말풍선은 타원/둥근 사각형과 꼬리, 패널은 행/열·여백·간격, 톤은 점/선, 효과는 재현 가능한 Speed/Focus 선이다. PNG/JPEG/WebP 재료는 외부 URL 대신 RGBA 픽셀을 프로젝트에 포함하고 위치·배율·회전·반복을 편집한다.

## 검증 결과

| 항목 | 결과 |
|---|---|
| 전체 Node 테스트 | 197/197 통과, 실패·생략 0; 기존 184개 검사 유지, 잘못된 정상 문서 예제 데이터 1건 보정 |
| production build | 통과 |
| 유니코드 Canvas 렌더링 | 결합 문자·ZWJ 이모지·줄바꿈·정렬·외곽선 검사 통과 |
| 실제 UI 조작 | 7개 그룹 통과: 여섯 도구·모든 속성·IME/포커스·잘못된 입력·잠금·이미지 가져오기·필터·배치 |
| 통합 브라우저 동작 | 12개 그룹 통과: 합성·히스토리·Navigator·저장/열기·복구·내보내기·Flatten·반복 재료 경계 |
| `.drawstudio` round-trip | 메타데이터·포함된 재료 픽셀·unknown extensions 유지, 재열기 전후 PNG 픽셀 동일 |
| autosave/recovery | IndexedDB 실제 기록 후 새로고침·명시적 복원, 픽셀·메타데이터·dirty 상태 확인 |
| 실패 안전성 | 손상된 파일/복구 거부; 기존 그림·제목·저장 파일 연결 유지 |
| PNG export | Draft 및 assist 표시 제외, 내보내기 결과 비교 |
| visual reference | 실제 1440×1000 화면과 정적 레퍼런스 비교, 1024×768 왼손 배치 확인 |
| ZIP 무결성 | CRC 통과, 소스·테스트·빌드 파일 포함 확인 |
| ZIP 새 폴더 재검증 | `npm ci`, 197개 테스트, production build, 유니코드 및 19개 브라우저 그룹 모두 통과 |
| 빌드 재현성 | 다시 만든 dist 파일 144개가 ZIP의 dist와 바이트 단위로 동일 |

검증 브라우저는 Chromium 133.0.6943.0이다. 환경의 npm http-proxy 경고는 설치·테스트 결과에 영향을 주지 않았다. 최종 ZIP 새 폴더에서 정상 `npm ci`는 3개 패키지를 설치하고 성공했다.

최종 테스트 로그는 명령 출력을 직접 보존한 `final-197-tests.log`이며, 최종 검증 요약은 `FINAL_VERIFICATION.log`이다.

## 검토 중 수정한 사항과 판단

유니코드 결합 문자 렌더링, 생성 전 텍스트 기본값의 표시/실제값 불일치, 없는 활성 레이어를 참조하는 손상된 문서의 부분 적용, 멀리 이동한 반복 재료의 누락을 수정하고 재현 테스트를 추가했다. 최종 수정 범위 재검토에서 두 마지막 항목 모두 해결 및 배포 가능 판정을 받았다.

기존 정상 문서 테스트 예제는 레이어가 없는데 background를 활성 레이어로 참조했다. 모든 검사 조건은 보존하고 실제 background 노드를 추가하는 것으로 판단했다. 이 판단이 잘못돼 레이어 없는 파일도 정식 지원해야 한다면, 렌더링 불가능한 문서의 별도 호환 규약을 정의해야 한다. 정상 편집기에서 생성한 프로젝트의 동작을 바꾸려는 수정은 아니다.

## 화면 비교와 한계

레퍼런스의 연결된 차콜 패널, 작은 도구 레일, Manga/Materials 중심 기본 패널, Properties/Layers 보조 패널 위계를 유지했다. 기존 Color·Navigator·Open/Save/Save As·Project Safety는 보존했으며 정적 표시 대신 실제 편집 필드를 제공했다. 샘플 그림까지 똑같은 픽셀 복제는 아니다.

자유곡선 말풍선, 임의 다각형 패널, 재료 마켓, 폰트 파일 포함은 범위 밖이다. 폰트는 시스템/브라우저에 따라 달라질 수 있다. 실제 iPad/Safari 검증은 아직 하지 않았으며 태블릿 검증은 Chromium 화면 크기·왼손 배치 기준이다. 큰 문서의 전체 픽셀 히스토리는 메모리 부담이 있다. 큰 재료의 base64 전체 문자열을 캐시 키로 비교하는 비용은 비차단 성능 후속 항목이다.

## 전달 파일

- `drawing-webapp-v0.6.7-restored.zip`: 소스·테스트·문서·dist. 541,920바이트, 314항목.
- ZIP SHA-256: `e6b3f3d1509f21cbaf081e1d1ef6fbc0416d74c07f59084ba813594dc399966b`
- `drawing-webapp-v0.6.7-history.bundle`: 원본부터 복원까지 Git 이력.
- `drawing-webapp-v0.6.7-evidence.zip`: 화면·검사 결과·로그·예제 프로젝트·전후 PNG·원본 비교 자료.
- `drawing-webapp-v0.6.7-preview.png`: 실제 실행 화면.

압축 해제 후 `drawing-webapp` 폴더에서 `node scripts/serve.mjs dist`로 포함된 빌드를 실행하고 `http://127.0.0.1:4173`을 연다. 소스 검증은 `npm ci`, `npm test`, `npm run build` 순서다. 브라우저 테스트는 `npx playwright install chromium` 후 `npm run test:browser`로 실행한다.
